document.querySelectorAll('.card').forEach(card => {
  card.addEventListener('click', () => {
    alert('Produto adicionado ao carrinho!');
  });
});
